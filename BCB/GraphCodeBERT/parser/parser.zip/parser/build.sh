git clone https://github.com/tree-sitter/tree-sitter-java

python build.py
